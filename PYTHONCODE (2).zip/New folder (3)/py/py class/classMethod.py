class Emp(object):
	def __init__(self,name,salary):
		self.name=name
		self.salary=salary
		return None
	def display(self):
		print(f"The name is: {self.name}\nThe salary is: {self.salary}")
		return None


emp1=Emp('Ramu',56000)
emp2=Emp("Naren",90000)

emp1.display()
emp2.display()