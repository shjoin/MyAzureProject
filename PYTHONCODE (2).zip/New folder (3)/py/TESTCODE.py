import datetime

chunk_file = 'dwh_tr_billing_recycle_ss_1.'+ datetime.datetime.now().strftime("%Y%m%d%H%M%S")
print("testing")
print(chunk_file)

#dwh_tr_billing_recycle_ss_1.1_20210219_18 34 54

