DbUser="dwh"
DbPassword="$dwh123"
DbTns="syndwd:1591/SYNDW.INT.SYNAPSEGROUPINC.COM"

