#default values will be used in all environments

HOME = 'C:/Users/sjoshi2/Documents/PythonShjo/MyProject'
SQLPLUS = 'C:/Oracle/app/client/product/12.1.0/client_64bit/BIN/sqlplus.exe'
GV_ERROR =0
GV_LOGname=''
GV_EMAIL_SUBJECT=''
GV_SEND_MAIL=''
IBS_SUCCESS_GROUP='shailendra.joshi@meredith.com'
GV_EMAIL_GROUP =IBS_SUCCESS_GROUP
GV_SEND_LOG_FILE = ''
GV_EXIT_FLAG=''
PYname=''