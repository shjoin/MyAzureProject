https://www.youtube.com/playlist?list=PLAUqwTOuQpYIZGhLNfUBBKaTd_k9WytIT




import_csv.bteq-->
 
 .LOGON 192.168.11.128/dbc,dbc;
 
 drop table CVS_TD_DB.Emp_VOLTemp;

 
  CREATE MULTISET VOLATILE TABLE Emp_VOLTemp as 
           (Select employee_id,employee_name,d.dept_id,position_,salary
                   from CVS_TD_DB.employee e ,CVS_TD_DB.dept d
				       where e.dept_id=d.dept_id and 1=3 ) 
				       with data primary index(employee_id)
				       on commit preserve rows;
					   
 .import indicdata file="C:\Teradata\BteqShjo\Employee.csv"
 
  using
 
 employee_id (varchar(10)),
 Employee_name (varchar(10)),
 Dept_id (interger) ,
 Position_ (varchar(20)),
 salary DECIMAL(13,2))
 
 insert into CVS_TD_DB.Emp_VOLTemp(:employee_id,:Employee_name,:Dept_id,:Position_,:salary);
 
 .logoff
 .quit
 
 
 
 
 

C:\Teradata\BteqShjo>bteq <import_csv.bteq >import_csv.log
 *** Failure 3807 Object 'CVS_TD_DB.Emp_VOLTemp' does not exist.
                Statement# 1, Info =0

 *** Error: The following occurred during an Access Module read:
 Unexpected data format !ERROR! End-of-file encountered before the expected end-of-record.

C:\Teradata\BteqShjo>





 .LOGON 192.168.11.128/dbc,dbc;
 
 
  CREATE MULTISET TABLE CVS_TD_DB.Emp_Report as 
           (Select employee_id,employee_name,d.dept_id,position_,salary
                   from CVS_TD_DB.employee e ,CVS_TD_DB.dept d
				       where e.dept_id=d.dept_id and 1=3 ) 
				       with data primary index(employee_id);
				       
					   
 .import report file="C:\Teradata\BteqShjo\Employee.csv"
 
  using
 
 employee_id (varchar(10)),
 Employee_name (varchar(10)),
 Dept_id (integer) ,
 Position_ (varchar(20)),
 salary (DECIMAL(13,2))
 
 insert into CVS_TD_DB.Emp_Report(:employee_id,:Employee_name,:Dept_id,:Position_,:salary);
 
 .logoff
 .quit
 
 
 
 LOGON dbc, dbc;
.import vartext '|' FILE = /root/ETL/new_revision/report.csv, skip=1;
.REPEAT *
 USING (
     EmpNo VARCHAR(2000)
    ,Name  VARCHAR(2000)
    ,hire_date VARCHAR(2000)
     )
INSERT INTO retail.employee_import
    VALUES (
    :EmpNo,
    :Name,
    CAST(:hire_date AS DATE),
    );
.QUIT
.LOGOFF

The source parcel length does not match data that was defined" error
This problem is fixed in the patched version of the Connect for ODBC Teradata driver V5.20.0061


