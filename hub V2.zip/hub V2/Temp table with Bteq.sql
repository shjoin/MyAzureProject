CREATE MULTISET VOLATILE TABLE Temptable, 
    NO FALLBACK , 
    NO BEFORE JOURNAL, 
    NO AFTER JOURNAL, 
    CHECKSUM = DEFAULT, 
    DEFAULT MERGEBLOCKRATIO 
        ( 
            Person CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,       
            Claim INTEGER, 
            Start_Date DATE FORMAT 'YY/MM/DD', 
            DaysSupply INTEGER, 
            End_Date DATE FORMAT 'YY/MM/DD' 
        ) 
    ON COMMIT PRESERVE ROWS; 

    
      CREATE MULTISET VOLATILE TABLE shjoin.Emp_VOLTemp as 
           (Select employee_id,employee_name,d.dept_id,position_,salary
                   from CVS_TD_DB.employee e ,CVS_TD_DB.dept d
           where e.dept_id=d.dept_id and 1=3 ) 
           with data primary index(employee_id)
           on commit preserve rows;
           
    
    select * from CVS_TD_DB.Emp_Report4;
    
    CREATE MULTISET VOLATILE TABLE Emp_VOLTemp as 
           (Select employee_id,employee_name,d.dept_id,position_,salary,dept_name
                   from CVS_TD_DB.employee e ,CVS_TD_DB.dept d
				       where e.dept_id=d.dept_id ) 
				       with data primary index(employee_id)
				       on commit preserve rows;
    
				       --<ScriptOptions statementTerminator=";"/>

drop table CVS_TD_DB.Emp_Report ;				       
				       
CREATE MULTISET TABLE CVS_TD_DB.Emp_Report4 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO,
     MAP = TD_MAP1
     (
      EMPLOYEE_ID INTEGER,
      EMPLOYEE_NAME VARCHAR(50) CHARACTER SET LATIN CASESPECIFIC,
      DEPT_ID INTEGER,
      POSITION_ VARCHAR(50) CHARACTER SET LATIN CASESPECIFIC,
      SALARY INTEGER)
PRIMARY INDEX ( EMPLOYEE_ID );


				       
			CREATE  global temporary TABLE Emp_Temp  
           (Select employee_id,employee_name,d.dept_id,position_,salary,dept_name
                   from CVS_TD_DB.employee e ,CVS_TD_DB.dept d
				       where e.dept_id=d.dept_id )
				       with no data
				       on commit preserve rows;
				       